

float getCookies(int a) {
	return 5.0;
}

int main() {
	int test = 5;

	// Uh oh, seems like I made a typo
	float well = getCookies(tedt);
}