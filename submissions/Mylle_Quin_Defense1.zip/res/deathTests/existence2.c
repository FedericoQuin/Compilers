

int main() {
	getCookies();
}