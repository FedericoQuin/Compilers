void someFunctionThatDoesNothing(int a) {return;}

int main() {
	int b = someFunctionThatDoesNothing(10);
}