
int main() {
	int* a;
	int* b;
	*(a+1+b) = 1;
}
