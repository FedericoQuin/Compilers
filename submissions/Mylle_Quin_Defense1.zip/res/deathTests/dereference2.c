
int main() {
	int* a = 0;

	int b[10];

	a = b;
	*(a+5) = 2.9;
}
