int main() {
	int y = 5;
	int x = 0;
	while(x < 5) {
		x++;
	}

	while (x > 0)
		while (y > 0) {
			y--;
			x--;
		}
}