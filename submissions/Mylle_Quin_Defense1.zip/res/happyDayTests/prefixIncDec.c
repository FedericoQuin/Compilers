
int main() {
	int a = 5;
	++a;

	int b = -10;
	--b;
}

