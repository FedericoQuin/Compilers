int main(int testArg, float testArg2, char testArg3);

int main(int testArg, float testArg2, char testArg3) {float x = 3.5;}

void somethingUseful(float uselessArgument);

void getThePointOfLife(int age){
	if (age > 100) {
		return;
	} else {
		while (age < 100) {
			age++;
		}
		return;
	}
}