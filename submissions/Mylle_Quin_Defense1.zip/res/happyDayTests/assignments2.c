int main(int argc, char argv, float test) {
    char a = 'd';
    int b = 510;
    float c = 59.12;
    float d = .35;
    float e = 0.04;
    int f = 0;
}