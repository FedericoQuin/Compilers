#include<stdio.h>

int main() {
	int a;
	int b;

	scanf("%d", a);
	scanf("%i", b);
	scanf("%i%d", b, a);

	char charval;
	scanf("%c", charval);

	char stringthing[20];
	scanf("%s", stringthing);
}