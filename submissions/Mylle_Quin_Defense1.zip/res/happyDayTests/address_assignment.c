int main() {
	int a = 5;

	int* b = &a;

	int intArray[10];

	b = &intArray[5];	
}