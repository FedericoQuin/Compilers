int main() {
	int a = -5;

	float b = -2.5;

	float c = -.968;

	a = -5 + -9;
}