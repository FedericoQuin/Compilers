int main(int argc, char* argv) {
	int***** x = 0;
}