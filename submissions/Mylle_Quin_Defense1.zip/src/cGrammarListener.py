# Generated from res/cGrammar.g4 by ANTLR 4.6
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .cGrammarParser import cGrammarParser
else:
    from cGrammarParser import cGrammarParser

# This class defines a complete listener for a parse tree produced by cGrammarParser.
class cGrammarListener(ParseTreeListener):

    # Enter a parse tree produced by cGrammarParser#program.
    def enterProgram(self, ctx:cGrammarParser.ProgramContext):
        pass

    # Exit a parse tree produced by cGrammarParser#program.
    def exitProgram(self, ctx:cGrammarParser.ProgramContext):
        pass


    # Enter a parse tree produced by cGrammarParser#include_file.
    def enterInclude_file(self, ctx:cGrammarParser.Include_fileContext):
        pass

    # Exit a parse tree produced by cGrammarParser#include_file.
    def exitInclude_file(self, ctx:cGrammarParser.Include_fileContext):
        pass


    # Enter a parse tree produced by cGrammarParser#function.
    def enterFunction(self, ctx:cGrammarParser.FunctionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#function.
    def exitFunction(self, ctx:cGrammarParser.FunctionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#functiondecl.
    def enterFunctiondecl(self, ctx:cGrammarParser.FunctiondeclContext):
        pass

    # Exit a parse tree produced by cGrammarParser#functiondecl.
    def exitFunctiondecl(self, ctx:cGrammarParser.FunctiondeclContext):
        pass


    # Enter a parse tree produced by cGrammarParser#initialfunctionargument.
    def enterInitialfunctionargument(self, ctx:cGrammarParser.InitialfunctionargumentContext):
        pass

    # Exit a parse tree produced by cGrammarParser#initialfunctionargument.
    def exitInitialfunctionargument(self, ctx:cGrammarParser.InitialfunctionargumentContext):
        pass


    # Enter a parse tree produced by cGrammarParser#type_arguments.
    def enterType_arguments(self, ctx:cGrammarParser.Type_argumentsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#type_arguments.
    def exitType_arguments(self, ctx:cGrammarParser.Type_argumentsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#type_argument.
    def enterType_argument(self, ctx:cGrammarParser.Type_argumentContext):
        pass

    # Exit a parse tree produced by cGrammarParser#type_argument.
    def exitType_argument(self, ctx:cGrammarParser.Type_argumentContext):
        pass


    # Enter a parse tree produced by cGrammarParser#function_body.
    def enterFunction_body(self, ctx:cGrammarParser.Function_bodyContext):
        pass

    # Exit a parse tree produced by cGrammarParser#function_body.
    def exitFunction_body(self, ctx:cGrammarParser.Function_bodyContext):
        pass


    # Enter a parse tree produced by cGrammarParser#statements.
    def enterStatements(self, ctx:cGrammarParser.StatementsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#statements.
    def exitStatements(self, ctx:cGrammarParser.StatementsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#statement.
    def enterStatement(self, ctx:cGrammarParser.StatementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#statement.
    def exitStatement(self, ctx:cGrammarParser.StatementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#break_stmt.
    def enterBreak_stmt(self, ctx:cGrammarParser.Break_stmtContext):
        pass

    # Exit a parse tree produced by cGrammarParser#break_stmt.
    def exitBreak_stmt(self, ctx:cGrammarParser.Break_stmtContext):
        pass


    # Enter a parse tree produced by cGrammarParser#continue_stmt.
    def enterContinue_stmt(self, ctx:cGrammarParser.Continue_stmtContext):
        pass

    # Exit a parse tree produced by cGrammarParser#continue_stmt.
    def exitContinue_stmt(self, ctx:cGrammarParser.Continue_stmtContext):
        pass


    # Enter a parse tree produced by cGrammarParser#return_stmt.
    def enterReturn_stmt(self, ctx:cGrammarParser.Return_stmtContext):
        pass

    # Exit a parse tree produced by cGrammarParser#return_stmt.
    def exitReturn_stmt(self, ctx:cGrammarParser.Return_stmtContext):
        pass


    # Enter a parse tree produced by cGrammarParser#expression.
    def enterExpression(self, ctx:cGrammarParser.ExpressionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#expression.
    def exitExpression(self, ctx:cGrammarParser.ExpressionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#add_sub.
    def enterAdd_sub(self, ctx:cGrammarParser.Add_subContext):
        pass

    # Exit a parse tree produced by cGrammarParser#add_sub.
    def exitAdd_sub(self, ctx:cGrammarParser.Add_subContext):
        pass


    # Enter a parse tree produced by cGrammarParser#mul_div.
    def enterMul_div(self, ctx:cGrammarParser.Mul_divContext):
        pass

    # Exit a parse tree produced by cGrammarParser#mul_div.
    def exitMul_div(self, ctx:cGrammarParser.Mul_divContext):
        pass


    # Enter a parse tree produced by cGrammarParser#bracket_expression.
    def enterBracket_expression(self, ctx:cGrammarParser.Bracket_expressionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#bracket_expression.
    def exitBracket_expression(self, ctx:cGrammarParser.Bracket_expressionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#lvalue_identifier.
    def enterLvalue_identifier(self, ctx:cGrammarParser.Lvalue_identifierContext):
        pass

    # Exit a parse tree produced by cGrammarParser#lvalue_identifier.
    def exitLvalue_identifier(self, ctx:cGrammarParser.Lvalue_identifierContext):
        pass


    # Enter a parse tree produced by cGrammarParser#rvalue_identifier.
    def enterRvalue_identifier(self, ctx:cGrammarParser.Rvalue_identifierContext):
        pass

    # Exit a parse tree produced by cGrammarParser#rvalue_identifier.
    def exitRvalue_identifier(self, ctx:cGrammarParser.Rvalue_identifierContext):
        pass


    # Enter a parse tree produced by cGrammarParser#ifelse.
    def enterIfelse(self, ctx:cGrammarParser.IfelseContext):
        pass

    # Exit a parse tree produced by cGrammarParser#ifelse.
    def exitIfelse(self, ctx:cGrammarParser.IfelseContext):
        pass


    # Enter a parse tree produced by cGrammarParser#else_statement.
    def enterElse_statement(self, ctx:cGrammarParser.Else_statementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#else_statement.
    def exitElse_statement(self, ctx:cGrammarParser.Else_statementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#firstcondition.
    def enterFirstcondition(self, ctx:cGrammarParser.FirstconditionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#firstcondition.
    def exitFirstcondition(self, ctx:cGrammarParser.FirstconditionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_true_statements.
    def enterFirst_true_statements(self, ctx:cGrammarParser.First_true_statementsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_true_statements.
    def exitFirst_true_statements(self, ctx:cGrammarParser.First_true_statementsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_true_statement.
    def enterFirst_true_statement(self, ctx:cGrammarParser.First_true_statementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_true_statement.
    def exitFirst_true_statement(self, ctx:cGrammarParser.First_true_statementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_false_statement.
    def enterFirst_false_statement(self, ctx:cGrammarParser.First_false_statementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_false_statement.
    def exitFirst_false_statement(self, ctx:cGrammarParser.First_false_statementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_false_statements.
    def enterFirst_false_statements(self, ctx:cGrammarParser.First_false_statementsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_false_statements.
    def exitFirst_false_statements(self, ctx:cGrammarParser.First_false_statementsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#condition.
    def enterCondition(self, ctx:cGrammarParser.ConditionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#condition.
    def exitCondition(self, ctx:cGrammarParser.ConditionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#condition_and.
    def enterCondition_and(self, ctx:cGrammarParser.Condition_andContext):
        pass

    # Exit a parse tree produced by cGrammarParser#condition_and.
    def exitCondition_and(self, ctx:cGrammarParser.Condition_andContext):
        pass


    # Enter a parse tree produced by cGrammarParser#condition_not.
    def enterCondition_not(self, ctx:cGrammarParser.Condition_notContext):
        pass

    # Exit a parse tree produced by cGrammarParser#condition_not.
    def exitCondition_not(self, ctx:cGrammarParser.Condition_notContext):
        pass


    # Enter a parse tree produced by cGrammarParser#bracket_condition.
    def enterBracket_condition(self, ctx:cGrammarParser.Bracket_conditionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#bracket_condition.
    def exitBracket_condition(self, ctx:cGrammarParser.Bracket_conditionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#comparison.
    def enterComparison(self, ctx:cGrammarParser.ComparisonContext):
        pass

    # Exit a parse tree produced by cGrammarParser#comparison.
    def exitComparison(self, ctx:cGrammarParser.ComparisonContext):
        pass


    # Enter a parse tree produced by cGrammarParser#comparator.
    def enterComparator(self, ctx:cGrammarParser.ComparatorContext):
        pass

    # Exit a parse tree produced by cGrammarParser#comparator.
    def exitComparator(self, ctx:cGrammarParser.ComparatorContext):
        pass


    # Enter a parse tree produced by cGrammarParser#while_loop.
    def enterWhile_loop(self, ctx:cGrammarParser.While_loopContext):
        pass

    # Exit a parse tree produced by cGrammarParser#while_loop.
    def exitWhile_loop(self, ctx:cGrammarParser.While_loopContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_while_statements.
    def enterFirst_while_statements(self, ctx:cGrammarParser.First_while_statementsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_while_statements.
    def exitFirst_while_statements(self, ctx:cGrammarParser.First_while_statementsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_while_statement.
    def enterFirst_while_statement(self, ctx:cGrammarParser.First_while_statementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_while_statement.
    def exitFirst_while_statement(self, ctx:cGrammarParser.First_while_statementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_while_condition.
    def enterFirst_while_condition(self, ctx:cGrammarParser.First_while_conditionContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_while_condition.
    def exitFirst_while_condition(self, ctx:cGrammarParser.First_while_conditionContext):
        pass


    # Enter a parse tree produced by cGrammarParser#for_loop.
    def enterFor_loop(self, ctx:cGrammarParser.For_loopContext):
        pass

    # Exit a parse tree produced by cGrammarParser#for_loop.
    def exitFor_loop(self, ctx:cGrammarParser.For_loopContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_for_statements.
    def enterFirst_for_statements(self, ctx:cGrammarParser.First_for_statementsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_for_statements.
    def exitFirst_for_statements(self, ctx:cGrammarParser.First_for_statementsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_for_statement.
    def enterFirst_for_statement(self, ctx:cGrammarParser.First_for_statementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_for_statement.
    def exitFirst_for_statement(self, ctx:cGrammarParser.First_for_statementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#first_stmt_for.
    def enterFirst_stmt_for(self, ctx:cGrammarParser.First_stmt_forContext):
        pass

    # Exit a parse tree produced by cGrammarParser#first_stmt_for.
    def exitFirst_stmt_for(self, ctx:cGrammarParser.First_stmt_forContext):
        pass


    # Enter a parse tree produced by cGrammarParser#second_stmt_for.
    def enterSecond_stmt_for(self, ctx:cGrammarParser.Second_stmt_forContext):
        pass

    # Exit a parse tree produced by cGrammarParser#second_stmt_for.
    def exitSecond_stmt_for(self, ctx:cGrammarParser.Second_stmt_forContext):
        pass


    # Enter a parse tree produced by cGrammarParser#third_stmt_for.
    def enterThird_stmt_for(self, ctx:cGrammarParser.Third_stmt_forContext):
        pass

    # Exit a parse tree produced by cGrammarParser#third_stmt_for.
    def exitThird_stmt_for(self, ctx:cGrammarParser.Third_stmt_forContext):
        pass


    # Enter a parse tree produced by cGrammarParser#scanf.
    def enterScanf(self, ctx:cGrammarParser.ScanfContext):
        pass

    # Exit a parse tree produced by cGrammarParser#scanf.
    def exitScanf(self, ctx:cGrammarParser.ScanfContext):
        pass


    # Enter a parse tree produced by cGrammarParser#printf.
    def enterPrintf(self, ctx:cGrammarParser.PrintfContext):
        pass

    # Exit a parse tree produced by cGrammarParser#printf.
    def exitPrintf(self, ctx:cGrammarParser.PrintfContext):
        pass


    # Enter a parse tree produced by cGrammarParser#format_string.
    def enterFormat_string(self, ctx:cGrammarParser.Format_stringContext):
        pass

    # Exit a parse tree produced by cGrammarParser#format_string.
    def exitFormat_string(self, ctx:cGrammarParser.Format_stringContext):
        pass


    # Enter a parse tree produced by cGrammarParser#functioncall.
    def enterFunctioncall(self, ctx:cGrammarParser.FunctioncallContext):
        pass

    # Exit a parse tree produced by cGrammarParser#functioncall.
    def exitFunctioncall(self, ctx:cGrammarParser.FunctioncallContext):
        pass


    # Enter a parse tree produced by cGrammarParser#call_argument_initial.
    def enterCall_argument_initial(self, ctx:cGrammarParser.Call_argument_initialContext):
        pass

    # Exit a parse tree produced by cGrammarParser#call_argument_initial.
    def exitCall_argument_initial(self, ctx:cGrammarParser.Call_argument_initialContext):
        pass


    # Enter a parse tree produced by cGrammarParser#call_arguments.
    def enterCall_arguments(self, ctx:cGrammarParser.Call_argumentsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#call_arguments.
    def exitCall_arguments(self, ctx:cGrammarParser.Call_argumentsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#call_argument.
    def enterCall_argument(self, ctx:cGrammarParser.Call_argumentContext):
        pass

    # Exit a parse tree produced by cGrammarParser#call_argument.
    def exitCall_argument(self, ctx:cGrammarParser.Call_argumentContext):
        pass


    # Enter a parse tree produced by cGrammarParser#declaration.
    def enterDeclaration(self, ctx:cGrammarParser.DeclarationContext):
        pass

    # Exit a parse tree produced by cGrammarParser#declaration.
    def exitDeclaration(self, ctx:cGrammarParser.DeclarationContext):
        pass


    # Enter a parse tree produced by cGrammarParser#normal_declaration.
    def enterNormal_declaration(self, ctx:cGrammarParser.Normal_declarationContext):
        pass

    # Exit a parse tree produced by cGrammarParser#normal_declaration.
    def exitNormal_declaration(self, ctx:cGrammarParser.Normal_declarationContext):
        pass


    # Enter a parse tree produced by cGrammarParser#array_declaration.
    def enterArray_declaration(self, ctx:cGrammarParser.Array_declarationContext):
        pass

    # Exit a parse tree produced by cGrammarParser#array_declaration.
    def exitArray_declaration(self, ctx:cGrammarParser.Array_declarationContext):
        pass


    # Enter a parse tree produced by cGrammarParser#assignment.
    def enterAssignment(self, ctx:cGrammarParser.AssignmentContext):
        pass

    # Exit a parse tree produced by cGrammarParser#assignment.
    def exitAssignment(self, ctx:cGrammarParser.AssignmentContext):
        pass


    # Enter a parse tree produced by cGrammarParser#initialization.
    def enterInitialization(self, ctx:cGrammarParser.InitializationContext):
        pass

    # Exit a parse tree produced by cGrammarParser#initialization.
    def exitInitialization(self, ctx:cGrammarParser.InitializationContext):
        pass


    # Enter a parse tree produced by cGrammarParser#global_declaration.
    def enterGlobal_declaration(self, ctx:cGrammarParser.Global_declarationContext):
        pass

    # Exit a parse tree produced by cGrammarParser#global_declaration.
    def exitGlobal_declaration(self, ctx:cGrammarParser.Global_declarationContext):
        pass


    # Enter a parse tree produced by cGrammarParser#lvalue.
    def enterLvalue(self, ctx:cGrammarParser.LvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#lvalue.
    def exitLvalue(self, ctx:cGrammarParser.LvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#lvalue_brackets.
    def enterLvalue_brackets(self, ctx:cGrammarParser.Lvalue_bracketsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#lvalue_brackets.
    def exitLvalue_brackets(self, ctx:cGrammarParser.Lvalue_bracketsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#rvalue.
    def enterRvalue(self, ctx:cGrammarParser.RvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#rvalue.
    def exitRvalue(self, ctx:cGrammarParser.RvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#arrayelement_rvalue.
    def enterArrayelement_rvalue(self, ctx:cGrammarParser.Arrayelement_rvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#arrayelement_rvalue.
    def exitArrayelement_rvalue(self, ctx:cGrammarParser.Arrayelement_rvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#arrayelement_lvalue.
    def enterArrayelement_lvalue(self, ctx:cGrammarParser.Arrayelement_lvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#arrayelement_lvalue.
    def exitArrayelement_lvalue(self, ctx:cGrammarParser.Arrayelement_lvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#arrayelement.
    def enterArrayelement(self, ctx:cGrammarParser.ArrayelementContext):
        pass

    # Exit a parse tree produced by cGrammarParser#arrayelement.
    def exitArrayelement(self, ctx:cGrammarParser.ArrayelementContext):
        pass


    # Enter a parse tree produced by cGrammarParser#charvalue.
    def enterCharvalue(self, ctx:cGrammarParser.CharvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#charvalue.
    def exitCharvalue(self, ctx:cGrammarParser.CharvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#numericalvalue.
    def enterNumericalvalue(self, ctx:cGrammarParser.NumericalvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#numericalvalue.
    def exitNumericalvalue(self, ctx:cGrammarParser.NumericalvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#intvalue.
    def enterIntvalue(self, ctx:cGrammarParser.IntvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#intvalue.
    def exitIntvalue(self, ctx:cGrammarParser.IntvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#floatvalue.
    def enterFloatvalue(self, ctx:cGrammarParser.FloatvalueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#floatvalue.
    def exitFloatvalue(self, ctx:cGrammarParser.FloatvalueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#address_value.
    def enterAddress_value(self, ctx:cGrammarParser.Address_valueContext):
        pass

    # Exit a parse tree produced by cGrammarParser#address_value.
    def exitAddress_value(self, ctx:cGrammarParser.Address_valueContext):
        pass


    # Enter a parse tree produced by cGrammarParser#pointer_dereference.
    def enterPointer_dereference(self, ctx:cGrammarParser.Pointer_dereferenceContext):
        pass

    # Exit a parse tree produced by cGrammarParser#pointer_dereference.
    def exitPointer_dereference(self, ctx:cGrammarParser.Pointer_dereferenceContext):
        pass


    # Enter a parse tree produced by cGrammarParser#dereference_bracket.
    def enterDereference_bracket(self, ctx:cGrammarParser.Dereference_bracketContext):
        pass

    # Exit a parse tree produced by cGrammarParser#dereference_bracket.
    def exitDereference_bracket(self, ctx:cGrammarParser.Dereference_bracketContext):
        pass


    # Enter a parse tree produced by cGrammarParser#ptr.
    def enterPtr(self, ctx:cGrammarParser.PtrContext):
        pass

    # Exit a parse tree produced by cGrammarParser#ptr.
    def exitPtr(self, ctx:cGrammarParser.PtrContext):
        pass


    # Enter a parse tree produced by cGrammarParser#digits.
    def enterDigits(self, ctx:cGrammarParser.DigitsContext):
        pass

    # Exit a parse tree produced by cGrammarParser#digits.
    def exitDigits(self, ctx:cGrammarParser.DigitsContext):
        pass


    # Enter a parse tree produced by cGrammarParser#returntype.
    def enterReturntype(self, ctx:cGrammarParser.ReturntypeContext):
        pass

    # Exit a parse tree produced by cGrammarParser#returntype.
    def exitReturntype(self, ctx:cGrammarParser.ReturntypeContext):
        pass


    # Enter a parse tree produced by cGrammarParser#dec_type.
    def enterDec_type(self, ctx:cGrammarParser.Dec_typeContext):
        pass

    # Exit a parse tree produced by cGrammarParser#dec_type.
    def exitDec_type(self, ctx:cGrammarParser.Dec_typeContext):
        pass


    # Enter a parse tree produced by cGrammarParser#prefix_inc.
    def enterPrefix_inc(self, ctx:cGrammarParser.Prefix_incContext):
        pass

    # Exit a parse tree produced by cGrammarParser#prefix_inc.
    def exitPrefix_inc(self, ctx:cGrammarParser.Prefix_incContext):
        pass


    # Enter a parse tree produced by cGrammarParser#postfix_inc.
    def enterPostfix_inc(self, ctx:cGrammarParser.Postfix_incContext):
        pass

    # Exit a parse tree produced by cGrammarParser#postfix_inc.
    def exitPostfix_inc(self, ctx:cGrammarParser.Postfix_incContext):
        pass


    # Enter a parse tree produced by cGrammarParser#prefix_dec.
    def enterPrefix_dec(self, ctx:cGrammarParser.Prefix_decContext):
        pass

    # Exit a parse tree produced by cGrammarParser#prefix_dec.
    def exitPrefix_dec(self, ctx:cGrammarParser.Prefix_decContext):
        pass


    # Enter a parse tree produced by cGrammarParser#postfix_dec.
    def enterPostfix_dec(self, ctx:cGrammarParser.Postfix_decContext):
        pass

    # Exit a parse tree produced by cGrammarParser#postfix_dec.
    def exitPostfix_dec(self, ctx:cGrammarParser.Postfix_decContext):
        pass


