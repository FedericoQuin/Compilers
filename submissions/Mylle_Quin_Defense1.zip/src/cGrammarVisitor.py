# Generated from res/cGrammar.g4 by ANTLR 4.6
from antlr4 import *
if __name__ is not None and "." in __name__:
    from .cGrammarParser import cGrammarParser
else:
    from cGrammarParser import cGrammarParser

# This class defines a complete generic visitor for a parse tree produced by cGrammarParser.

class cGrammarVisitor(ParseTreeVisitor):

    # Visit a parse tree produced by cGrammarParser#program.
    def visitProgram(self, ctx:cGrammarParser.ProgramContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#include_file.
    def visitInclude_file(self, ctx:cGrammarParser.Include_fileContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#function.
    def visitFunction(self, ctx:cGrammarParser.FunctionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#functiondecl.
    def visitFunctiondecl(self, ctx:cGrammarParser.FunctiondeclContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#initialfunctionargument.
    def visitInitialfunctionargument(self, ctx:cGrammarParser.InitialfunctionargumentContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#type_arguments.
    def visitType_arguments(self, ctx:cGrammarParser.Type_argumentsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#type_argument.
    def visitType_argument(self, ctx:cGrammarParser.Type_argumentContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#function_body.
    def visitFunction_body(self, ctx:cGrammarParser.Function_bodyContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#statements.
    def visitStatements(self, ctx:cGrammarParser.StatementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#statement.
    def visitStatement(self, ctx:cGrammarParser.StatementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#break_stmt.
    def visitBreak_stmt(self, ctx:cGrammarParser.Break_stmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#continue_stmt.
    def visitContinue_stmt(self, ctx:cGrammarParser.Continue_stmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#return_stmt.
    def visitReturn_stmt(self, ctx:cGrammarParser.Return_stmtContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#expression.
    def visitExpression(self, ctx:cGrammarParser.ExpressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#add_sub.
    def visitAdd_sub(self, ctx:cGrammarParser.Add_subContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#mul_div.
    def visitMul_div(self, ctx:cGrammarParser.Mul_divContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#bracket_expression.
    def visitBracket_expression(self, ctx:cGrammarParser.Bracket_expressionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#lvalue_identifier.
    def visitLvalue_identifier(self, ctx:cGrammarParser.Lvalue_identifierContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#rvalue_identifier.
    def visitRvalue_identifier(self, ctx:cGrammarParser.Rvalue_identifierContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#ifelse.
    def visitIfelse(self, ctx:cGrammarParser.IfelseContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#else_statement.
    def visitElse_statement(self, ctx:cGrammarParser.Else_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#firstcondition.
    def visitFirstcondition(self, ctx:cGrammarParser.FirstconditionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_true_statements.
    def visitFirst_true_statements(self, ctx:cGrammarParser.First_true_statementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_true_statement.
    def visitFirst_true_statement(self, ctx:cGrammarParser.First_true_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_false_statement.
    def visitFirst_false_statement(self, ctx:cGrammarParser.First_false_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_false_statements.
    def visitFirst_false_statements(self, ctx:cGrammarParser.First_false_statementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#condition.
    def visitCondition(self, ctx:cGrammarParser.ConditionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#condition_and.
    def visitCondition_and(self, ctx:cGrammarParser.Condition_andContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#condition_not.
    def visitCondition_not(self, ctx:cGrammarParser.Condition_notContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#bracket_condition.
    def visitBracket_condition(self, ctx:cGrammarParser.Bracket_conditionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#comparison.
    def visitComparison(self, ctx:cGrammarParser.ComparisonContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#comparator.
    def visitComparator(self, ctx:cGrammarParser.ComparatorContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#while_loop.
    def visitWhile_loop(self, ctx:cGrammarParser.While_loopContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_while_statements.
    def visitFirst_while_statements(self, ctx:cGrammarParser.First_while_statementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_while_statement.
    def visitFirst_while_statement(self, ctx:cGrammarParser.First_while_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_while_condition.
    def visitFirst_while_condition(self, ctx:cGrammarParser.First_while_conditionContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#for_loop.
    def visitFor_loop(self, ctx:cGrammarParser.For_loopContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_for_statements.
    def visitFirst_for_statements(self, ctx:cGrammarParser.First_for_statementsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_for_statement.
    def visitFirst_for_statement(self, ctx:cGrammarParser.First_for_statementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#first_stmt_for.
    def visitFirst_stmt_for(self, ctx:cGrammarParser.First_stmt_forContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#second_stmt_for.
    def visitSecond_stmt_for(self, ctx:cGrammarParser.Second_stmt_forContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#third_stmt_for.
    def visitThird_stmt_for(self, ctx:cGrammarParser.Third_stmt_forContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#scanf.
    def visitScanf(self, ctx:cGrammarParser.ScanfContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#printf.
    def visitPrintf(self, ctx:cGrammarParser.PrintfContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#format_string.
    def visitFormat_string(self, ctx:cGrammarParser.Format_stringContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#functioncall.
    def visitFunctioncall(self, ctx:cGrammarParser.FunctioncallContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#call_argument_initial.
    def visitCall_argument_initial(self, ctx:cGrammarParser.Call_argument_initialContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#call_arguments.
    def visitCall_arguments(self, ctx:cGrammarParser.Call_argumentsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#call_argument.
    def visitCall_argument(self, ctx:cGrammarParser.Call_argumentContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#declaration.
    def visitDeclaration(self, ctx:cGrammarParser.DeclarationContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#normal_declaration.
    def visitNormal_declaration(self, ctx:cGrammarParser.Normal_declarationContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#array_declaration.
    def visitArray_declaration(self, ctx:cGrammarParser.Array_declarationContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#assignment.
    def visitAssignment(self, ctx:cGrammarParser.AssignmentContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#initialization.
    def visitInitialization(self, ctx:cGrammarParser.InitializationContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#global_declaration.
    def visitGlobal_declaration(self, ctx:cGrammarParser.Global_declarationContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#lvalue.
    def visitLvalue(self, ctx:cGrammarParser.LvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#lvalue_brackets.
    def visitLvalue_brackets(self, ctx:cGrammarParser.Lvalue_bracketsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#rvalue.
    def visitRvalue(self, ctx:cGrammarParser.RvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#arrayelement_rvalue.
    def visitArrayelement_rvalue(self, ctx:cGrammarParser.Arrayelement_rvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#arrayelement_lvalue.
    def visitArrayelement_lvalue(self, ctx:cGrammarParser.Arrayelement_lvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#arrayelement.
    def visitArrayelement(self, ctx:cGrammarParser.ArrayelementContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#charvalue.
    def visitCharvalue(self, ctx:cGrammarParser.CharvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#numericalvalue.
    def visitNumericalvalue(self, ctx:cGrammarParser.NumericalvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#intvalue.
    def visitIntvalue(self, ctx:cGrammarParser.IntvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#floatvalue.
    def visitFloatvalue(self, ctx:cGrammarParser.FloatvalueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#address_value.
    def visitAddress_value(self, ctx:cGrammarParser.Address_valueContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#pointer_dereference.
    def visitPointer_dereference(self, ctx:cGrammarParser.Pointer_dereferenceContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#dereference_bracket.
    def visitDereference_bracket(self, ctx:cGrammarParser.Dereference_bracketContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#ptr.
    def visitPtr(self, ctx:cGrammarParser.PtrContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#digits.
    def visitDigits(self, ctx:cGrammarParser.DigitsContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#returntype.
    def visitReturntype(self, ctx:cGrammarParser.ReturntypeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#dec_type.
    def visitDec_type(self, ctx:cGrammarParser.Dec_typeContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#prefix_inc.
    def visitPrefix_inc(self, ctx:cGrammarParser.Prefix_incContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#postfix_inc.
    def visitPostfix_inc(self, ctx:cGrammarParser.Postfix_incContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#prefix_dec.
    def visitPrefix_dec(self, ctx:cGrammarParser.Prefix_decContext):
        return self.visitChildren(ctx)


    # Visit a parse tree produced by cGrammarParser#postfix_dec.
    def visitPostfix_dec(self, ctx:cGrammarParser.Postfix_decContext):
        return self.visitChildren(ctx)



del cGrammarParser