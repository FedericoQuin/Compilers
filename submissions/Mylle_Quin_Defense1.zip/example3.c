
float main() {
	// Array of pointer to pointer to ints
	int a[10];
	int* ptrToArray = a;
	*(ptrToArray + 5) = 9;

	char b[100];

	b[10] = 't';

	for (int i = 0; i < 100; i++) {
		b[i*2+5] = 'a';
	}

	return .96387;
}
