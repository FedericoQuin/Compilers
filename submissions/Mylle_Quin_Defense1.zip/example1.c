
#include <stdio.h>
#include <myownheader.withsomeformat>

int doSomethingUseful(int a, char& b) {
	b = 't';
	if (a == 5) {
		++a;
	} else {
		a = 42;
	}

	return a;
}

int main(int argc, char* argv) {
	int myInt = 5;
	char myChar = 'b';

	int resultFunction = doSomethingUseful(myInt, myChar);

	for (int i = 0; i < resultFunction; i++) {
		printf("%i", i);
	}

	return 0;
}