
int GLOBAL_INT = 100;

int main(int argc) {
	int myInt = 10;
	int* ptrInt = &myInt;

	*ptrInt = GLOBAL_INT;

	while (myInt > 20) {
		*ptrInt = myInt - 1;
		
	}

	return myInt;
}
