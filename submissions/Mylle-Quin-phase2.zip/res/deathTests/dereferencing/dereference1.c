int main() {

	int*** a = 0;

	****a = 5;
}