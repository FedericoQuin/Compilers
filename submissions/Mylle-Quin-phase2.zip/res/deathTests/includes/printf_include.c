
int main() {
	int a = 10;

	printf("Here is my variable: %i.\n", a);
}

