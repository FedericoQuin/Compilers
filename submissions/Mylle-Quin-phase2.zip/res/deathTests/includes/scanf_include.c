
int main() {
	float b;

	scanf("%f", b);

}
