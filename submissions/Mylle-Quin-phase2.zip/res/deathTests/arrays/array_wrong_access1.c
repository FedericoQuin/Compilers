int main() {
	int a[10];

	a[5] = 28;
	a['a'] = 2;
}