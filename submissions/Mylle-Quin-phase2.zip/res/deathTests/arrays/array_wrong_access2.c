

int main() {
	char myString[10];

	myString[(2.0 * 8.6) + 9.3] = 't';
}
