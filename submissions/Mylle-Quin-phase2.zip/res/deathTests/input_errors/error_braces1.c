int main(){
	int someDecl = 0;	
