int main() {
	int test = 5;

	float b = 10;

	char c = 0.9;
}