
int testing(int var) {
	if (var == 5) {
		return 10;
	}
	return 0;
}

int testing(int var) {
	return var;
}

int main() {
	return testing(5);
}