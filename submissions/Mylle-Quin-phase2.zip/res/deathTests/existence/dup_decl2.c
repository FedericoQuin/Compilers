int testing() {return 0;}

int main() {
	// Perfectly fine
	float testing = 0.4;

	// Not fine anymore
	char* testing = 0;
}