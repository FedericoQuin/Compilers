

int mained() {
	int a = 5;

	return a + 10;
}
