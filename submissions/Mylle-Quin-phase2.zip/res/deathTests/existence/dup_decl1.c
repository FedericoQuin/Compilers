int main() {
	int a = 5;
	float a = 10.0;
}