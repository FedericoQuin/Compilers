int test();

int main() {
	int a = test();
}