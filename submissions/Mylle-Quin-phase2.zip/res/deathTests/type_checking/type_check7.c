int wrongTypes(int a, int b) {return a + b;}

int main() {
	int result = wrongTypes(5, 'q');
}