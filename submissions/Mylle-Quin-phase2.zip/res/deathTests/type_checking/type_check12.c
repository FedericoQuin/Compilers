
int testingAThing(int& a) {
	return a + 5;
}


int main() {
	int a = 5;

	// int b = testingAThing(a + 5);
}


