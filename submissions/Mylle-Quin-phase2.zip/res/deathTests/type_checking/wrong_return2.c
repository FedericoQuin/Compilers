void testing() {
	return 5;
}

int main() {
	testing();
}