
int aFunction(int& a) {
	return a;
}


int main() {
	int b = aFunction(5);
}

