
#include <stdio.h>

int main() {
	int a = 10;
	char b = 't';

	printf("My int: %i, my string: %s\n", a, b);
}
