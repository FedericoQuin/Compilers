int getCookies() {return 0;}
float getCookies2(int a, float b);

int main() {
	getCookies(5);
}