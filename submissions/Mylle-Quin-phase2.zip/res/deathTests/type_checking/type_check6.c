void something();
int somethingElse(int a, char test, float no) {return a;}

int main() {
	somethingElse(5, 'a', 3.14, 78);
}