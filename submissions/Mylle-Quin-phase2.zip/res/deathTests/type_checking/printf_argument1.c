
#include <stdio.h>

int main() {
	int a = 5;

	printf("Let's print my int: %c.\n", a);
}
