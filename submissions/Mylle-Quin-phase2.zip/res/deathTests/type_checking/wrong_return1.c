int testing() {
	return 'a';
}

int main() {
	int a = testing();
}