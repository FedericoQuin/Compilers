
#include <stdio.h>

int main() {
	float a;
	int b;
	char c;

	scanf("%i%c%i", b, c, a);
}

