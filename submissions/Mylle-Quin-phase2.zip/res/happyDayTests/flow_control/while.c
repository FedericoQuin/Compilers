int main() {
	int y = 5;
	int x = 0;
	while(x < 5) {
		x = x + 1;
	}

	while (x > 0)
		while (y > 0) {
			y = y - 1;
			x = x - 1;
		}
}