int main () {
	for (;;) {
		break;
	}

	int x = 5;
	while (x > 0) {
		if (x > 0) {
			x = x - 1;
			continue;
		}
		int unreachableLol = 5;
	}
}