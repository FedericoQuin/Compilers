int main() {
	for (;;) {}

	int c = 0;
	for (int i = 0; i < 5; i = i + 1) {int omaigod = 5;}
	for (; c < 5; c = c + 1) {int omaigod = 6;}
	for (int i = 0;; i = i + 1) {int omaigod = 7;}
	for (int y = 0; y < 5; y = y + 1) int omaigod = 8;
}