

int main() {
	int a = 5;

	int b = 10;

	bool condition = (a == 5) && b == 10;
	bool condition2 = (a == 6) and b == 10;

	if (condition) {
		int c = 20;
	}

	if (condition2) {
		a = 20;
	}

	return a;
}