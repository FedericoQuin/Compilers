int main(int argc, char* argv) {
	int* x;
	x = &argc;
}