

int main() {
	int a = 20;

	int b = -a + 20;


	int c = -( b * (-a) + -50 );

	return (a --b);
}

