

void testing(int& a) {
	a = 5;
	return;
}

int main() {
	int intVar = 10;
	testing(intVar);
}
