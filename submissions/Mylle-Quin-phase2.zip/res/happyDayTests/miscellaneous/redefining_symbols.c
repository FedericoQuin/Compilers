int testing(int a) {return a;}


int main() {

	int a = testing(5);

	if (a == 5) {
		int testing = 10;
		return testing;
	}
}