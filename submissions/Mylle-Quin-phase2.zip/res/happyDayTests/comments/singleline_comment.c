int main(int argc, char argv) {
	int testing;
	// this is just a comment that should do nothing, but still get parsed
	float sure;
}