
int main(int argc, char argv) {
	/* multiline comment for the sake of it
	a
	1
	9
	*/
	char name;
	float testing;
}
