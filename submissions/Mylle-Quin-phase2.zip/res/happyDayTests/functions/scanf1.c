#include <stdio.h>

int main() {
	int a;
	int b;

	scanf("%d", a);
	scanf("%i", b);
	scanf("%i%i", b, a);

	char charval;
	scanf("%c", charval);

	float yes;
	scanf("%f", yes);
}