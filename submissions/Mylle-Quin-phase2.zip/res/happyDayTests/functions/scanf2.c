
#include <stdio.h>

int main() {
	char word[5];

	scanf("%s", word);
}
