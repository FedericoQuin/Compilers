int testing() {}

int main() {
	int a = testing();
}