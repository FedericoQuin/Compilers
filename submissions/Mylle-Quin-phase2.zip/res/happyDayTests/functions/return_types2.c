void doNotReturn(int a) {
	a = 5;
}

int main() {
	doNotReturn(85);
}