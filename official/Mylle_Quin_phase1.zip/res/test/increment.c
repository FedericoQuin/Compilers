int main() {
	int c = 5;
	c++;
	c--;
}