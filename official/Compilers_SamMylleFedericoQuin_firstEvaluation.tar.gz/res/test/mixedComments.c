

void main(float test) {
	/* hello */
	/// there

	int jmp;

	/* one
	 * step
	 * at
	 * a
	 * time
	 */
}
