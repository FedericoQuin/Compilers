
int GLOBALVAR1 = 0;

int main() {
	int inMain = 6;
}

float globalvar2 = 4.96;


float testFunction(int a) {
	globalvar2 = 2.98;
}
