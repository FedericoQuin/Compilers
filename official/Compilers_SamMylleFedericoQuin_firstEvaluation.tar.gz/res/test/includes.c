#include <iostream>

#include <test.hpp>
#include <supersecretproject/idk.myownformat>

int main(int argc, char* argv) {
	float tests = 0.0;
}

#include <idontdoanything>