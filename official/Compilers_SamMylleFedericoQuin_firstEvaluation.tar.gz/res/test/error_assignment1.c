int main() {
	int a = 5;
	char b = 'a';

	a = b;
}