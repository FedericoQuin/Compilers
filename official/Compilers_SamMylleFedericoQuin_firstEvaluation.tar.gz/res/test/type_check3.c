int main () {
	int a = 5 + 2.0;
}