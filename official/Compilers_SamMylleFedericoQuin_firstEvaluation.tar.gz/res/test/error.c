int main(){
	


	int someErrorShouldHaveHappened = 0;
	int ok = 5;
