int main() {
	int a = 5;
	float b = 10.0;
	if (a > b) {}
}