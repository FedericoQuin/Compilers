

int main(int argc, char argv) {
    // Simple program that tests assignments
    int my_a;
}
