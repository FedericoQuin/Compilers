int main() {
	for (;;) {}

	int c = 0;
	for (int i = 0; i < 5; i++) {int omaigod = 5;}
	for (; c < 5; c++) {int omaigod = 6;}
	for (int i = 0;; i++) {int omaigod = 7;}
	for (int y = 0; y < 5; y++) int omaigod = 8;
}