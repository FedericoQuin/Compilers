#include<stdio.h>

int main() {
	int a = 5;
	int b = 10;
	char c = 'a';
	float d = .938;

	printf("The value of my first variable is %i", a);
	printf("The following 2 variables have values %i and %c", b, c);
	printf("I also have a float: %a", d);
}