

int main(int argc, char argv) {
    // Simple program that tests assignments
    int a = 10 + 5;
    int b = 10 * 5 + a;
}