int main()
	int someDecl = (5 + 8) * 3 * (5 + 4);
}