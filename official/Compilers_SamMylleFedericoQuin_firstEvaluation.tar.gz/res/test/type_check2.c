int main() {
	int a = 5;
	float b = a;
}