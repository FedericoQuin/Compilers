int main() {
	char a = 5;
}