int main() {
	int decl1 = 0;
	int decl2 = 5
}