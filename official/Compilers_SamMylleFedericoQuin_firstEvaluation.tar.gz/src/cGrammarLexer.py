# Generated from res/cGrammar.g4 by ANTLR 4.6
from antlr4 import *
from io import StringIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\2\64")
        buf.write("\u0163\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7")
        buf.write("\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r")
        buf.write("\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22\4\23")
        buf.write("\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4\30\t\30")
        buf.write("\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35\t\35\4\36")
        buf.write("\t\36\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4$\t$\4%\t%")
        buf.write("\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4,\t,\4-\t-\4.")
        buf.write("\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63\t\63\3\2")
        buf.write("\3\2\3\3\3\3\3\4\3\4\3\5\3\5\3\6\3\6\3\6\3\6\3\6\3\6\3")
        buf.write("\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b")
        buf.write("\3\b\3\b\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\13\3\13\3\13")
        buf.write("\3\13\3\13\3\13\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r\3\r\3")
        buf.write("\r\3\16\3\16\3\16\3\16\3\16\3\16\3\16\3\17\3\17\3\20\3")
        buf.write("\20\3\21\3\21\3\21\3\22\3\22\3\22\3\23\3\23\3\23\3\24")
        buf.write("\3\24\3\24\3\25\3\25\3\26\3\26\3\27\3\27\3\30\3\30\3\30")
        buf.write("\3\31\3\31\3\31\3\32\3\32\3\33\3\33\3\33\3\33\5\33\u00c7")
        buf.write("\n\33\3\34\3\34\3\35\3\35\3\35\3\35\5\35\u00cf\n\35\3")
        buf.write("\36\3\36\3\36\3\36\5\36\u00d5\n\36\3\37\3\37\3\37\3\37")
        buf.write("\3\37\5\37\u00dc\n\37\3 \3 \3 \3 \5 \u00e2\n \3!\3!\3")
        buf.write("!\3!\3!\3!\3!\3!\3!\3\"\3\"\3\"\7\"\u00f0\n\"\f\"\16\"")
        buf.write("\u00f3\13\"\3\"\3\"\3\"\3\"\7\"\u00f9\n\"\f\"\16\"\u00fc")
        buf.write("\13\"\3\"\3\"\7\"\u0100\n\"\f\"\16\"\u0103\13\"\3\"\3")
        buf.write("\"\5\"\u0107\n\"\3#\3#\3$\3$\3%\3%\3&\3&\3\'\3\'\3\'\3")
        buf.write("\'\3(\3(\3(\3(\3(\3)\3)\3)\3)\3)\3*\3*\3*\3*\3*\3*\3+")
        buf.write("\3+\3+\3+\3,\3,\3-\3-\3.\5.\u012e\n.\3.\7.\u0131\n.\f")
        buf.write(".\16.\u0134\13.\3/\3/\3\60\3\60\7\60\u013a\n\60\f\60\16")
        buf.write("\60\u013d\13\60\3\60\3\60\3\61\6\61\u0142\n\61\r\61\16")
        buf.write("\61\u0143\3\61\3\61\3\62\3\62\3\62\3\62\7\62\u014c\n\62")
        buf.write("\f\62\16\62\u014f\13\62\3\62\3\62\3\62\3\62\3\63\3\63")
        buf.write("\3\63\3\63\3\63\7\63\u015a\n\63\f\63\16\63\u015d\13\63")
        buf.write("\3\63\3\63\3\63\3\63\3\63\7\u00f1\u0101\u013b\u014d\u015b")
        buf.write("\2\64\3\3\5\4\7\5\t\6\13\7\r\b\17\t\21\n\23\13\25\f\27")
        buf.write("\r\31\16\33\17\35\20\37\21!\22#\23%\24\'\25)\26+\27-\30")
        buf.write("/\31\61\32\63\33\65\34\67\359\36;\37= ?!A\"C#E$G%I&K\'")
        buf.write("M(O)Q*S+U,W-Y.[/]\60_\61a\62c\63e\64\3\2\7\3\2\62;\3\2")
        buf.write("\63;\5\2C\\aac|\6\2\62;C\\aac|\5\2\13\f\17\17\"\"\u0171")
        buf.write("\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2\2\2\t\3\2\2\2\2\13")
        buf.write("\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2\2\21\3\2\2\2\2\23\3")
        buf.write("\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2\2\31\3\2\2\2\2\33\3\2")
        buf.write("\2\2\2\35\3\2\2\2\2\37\3\2\2\2\2!\3\2\2\2\2#\3\2\2\2\2")
        buf.write("%\3\2\2\2\2\'\3\2\2\2\2)\3\2\2\2\2+\3\2\2\2\2-\3\2\2\2")
        buf.write("\2/\3\2\2\2\2\61\3\2\2\2\2\63\3\2\2\2\2\65\3\2\2\2\2\67")
        buf.write("\3\2\2\2\29\3\2\2\2\2;\3\2\2\2\2=\3\2\2\2\2?\3\2\2\2\2")
        buf.write("A\3\2\2\2\2C\3\2\2\2\2E\3\2\2\2\2G\3\2\2\2\2I\3\2\2\2")
        buf.write("\2K\3\2\2\2\2M\3\2\2\2\2O\3\2\2\2\2Q\3\2\2\2\2S\3\2\2")
        buf.write("\2\2U\3\2\2\2\2W\3\2\2\2\2Y\3\2\2\2\2[\3\2\2\2\2]\3\2")
        buf.write("\2\2\2_\3\2\2\2\2a\3\2\2\2\2c\3\2\2\2\2e\3\2\2\2\3g\3")
        buf.write("\2\2\2\5i\3\2\2\2\7k\3\2\2\2\tm\3\2\2\2\13o\3\2\2\2\r")
        buf.write("u\3\2\2\2\17~\3\2\2\2\21\u0085\3\2\2\2\23\u0088\3\2\2")
        buf.write("\2\25\u008d\3\2\2\2\27\u0093\3\2\2\2\31\u0097\3\2\2\2")
        buf.write("\33\u009d\3\2\2\2\35\u00a4\3\2\2\2\37\u00a6\3\2\2\2!\u00a8")
        buf.write("\3\2\2\2#\u00ab\3\2\2\2%\u00ae\3\2\2\2\'\u00b1\3\2\2\2")
        buf.write(")\u00b4\3\2\2\2+\u00b6\3\2\2\2-\u00b8\3\2\2\2/\u00ba\3")
        buf.write("\2\2\2\61\u00bd\3\2\2\2\63\u00c0\3\2\2\2\65\u00c6\3\2")
        buf.write("\2\2\67\u00c8\3\2\2\29\u00ce\3\2\2\2;\u00d4\3\2\2\2=\u00db")
        buf.write("\3\2\2\2?\u00e1\3\2\2\2A\u00e3\3\2\2\2C\u0106\3\2\2\2")
        buf.write("E\u0108\3\2\2\2G\u010a\3\2\2\2I\u010c\3\2\2\2K\u010e\3")
        buf.write("\2\2\2M\u0110\3\2\2\2O\u0114\3\2\2\2Q\u0119\3\2\2\2S\u011e")
        buf.write("\3\2\2\2U\u0124\3\2\2\2W\u0128\3\2\2\2Y\u012a\3\2\2\2")
        buf.write("[\u012d\3\2\2\2]\u0135\3\2\2\2_\u0137\3\2\2\2a\u0141\3")
        buf.write("\2\2\2c\u0147\3\2\2\2e\u0154\3\2\2\2gh\7=\2\2h\4\3\2\2")
        buf.write("\2ij\7}\2\2j\6\3\2\2\2kl\7\177\2\2l\b\3\2\2\2mn\7.\2\2")
        buf.write("n\n\3\2\2\2op\7d\2\2pq\7t\2\2qr\7g\2\2rs\7c\2\2st\7m\2")
        buf.write("\2t\f\3\2\2\2uv\7e\2\2vw\7q\2\2wx\7p\2\2xy\7v\2\2yz\7")
        buf.write("k\2\2z{\7p\2\2{|\7w\2\2|}\7g\2\2}\16\3\2\2\2~\177\7t\2")
        buf.write("\2\177\u0080\7g\2\2\u0080\u0081\7v\2\2\u0081\u0082\7w")
        buf.write("\2\2\u0082\u0083\7t\2\2\u0083\u0084\7p\2\2\u0084\20\3")
        buf.write("\2\2\2\u0085\u0086\7k\2\2\u0086\u0087\7h\2\2\u0087\22")
        buf.write("\3\2\2\2\u0088\u0089\7g\2\2\u0089\u008a\7n\2\2\u008a\u008b")
        buf.write("\7u\2\2\u008b\u008c\7g\2\2\u008c\24\3\2\2\2\u008d\u008e")
        buf.write("\7y\2\2\u008e\u008f\7j\2\2\u008f\u0090\7k\2\2\u0090\u0091")
        buf.write("\7n\2\2\u0091\u0092\7g\2\2\u0092\26\3\2\2\2\u0093\u0094")
        buf.write("\7h\2\2\u0094\u0095\7q\2\2\u0095\u0096\7t\2\2\u0096\30")
        buf.write("\3\2\2\2\u0097\u0098\7u\2\2\u0098\u0099\7e\2\2\u0099\u009a")
        buf.write("\7c\2\2\u009a\u009b\7p\2\2\u009b\u009c\7h\2\2\u009c\32")
        buf.write("\3\2\2\2\u009d\u009e\7r\2\2\u009e\u009f\7t\2\2\u009f\u00a0")
        buf.write("\7k\2\2\u00a0\u00a1\7p\2\2\u00a1\u00a2\7v\2\2\u00a2\u00a3")
        buf.write("\7h\2\2\u00a3\34\3\2\2\2\u00a4\u00a5\7?\2\2\u00a5\36\3")
        buf.write("\2\2\2\u00a6\u00a7\7-\2\2\u00a7 \3\2\2\2\u00a8\u00a9\7")
        buf.write("-\2\2\u00a9\u00aa\7-\2\2\u00aa\"\3\2\2\2\u00ab\u00ac\7")
        buf.write("/\2\2\u00ac\u00ad\7/\2\2\u00ad$\3\2\2\2\u00ae\u00af\7")
        buf.write("-\2\2\u00af\u00b0\7-\2\2\u00b0&\3\2\2\2\u00b1\u00b2\7")
        buf.write("/\2\2\u00b2\u00b3\7/\2\2\u00b3(\3\2\2\2\u00b4\u00b5\7")
        buf.write("/\2\2\u00b5*\3\2\2\2\u00b6\u00b7\7\61\2\2\u00b7,\3\2\2")
        buf.write("\2\u00b8\u00b9\7,\2\2\u00b9.\3\2\2\2\u00ba\u00bb\7?\2")
        buf.write("\2\u00bb\u00bc\7?\2\2\u00bc\60\3\2\2\2\u00bd\u00be\7#")
        buf.write("\2\2\u00be\u00bf\7?\2\2\u00bf\62\3\2\2\2\u00c0\u00c1\7")
        buf.write("@\2\2\u00c1\64\3\2\2\2\u00c2\u00c3\7@\2\2\u00c3\u00c7")
        buf.write("\7?\2\2\u00c4\u00c5\7?\2\2\u00c5\u00c7\7@\2\2\u00c6\u00c2")
        buf.write("\3\2\2\2\u00c6\u00c4\3\2\2\2\u00c7\66\3\2\2\2\u00c8\u00c9")
        buf.write("\7>\2\2\u00c98\3\2\2\2\u00ca\u00cb\7>\2\2\u00cb\u00cf")
        buf.write("\7?\2\2\u00cc\u00cd\7?\2\2\u00cd\u00cf\7>\2\2\u00ce\u00ca")
        buf.write("\3\2\2\2\u00ce\u00cc\3\2\2\2\u00cf:\3\2\2\2\u00d0\u00d1")
        buf.write("\7~\2\2\u00d1\u00d5\7~\2\2\u00d2\u00d3\7q\2\2\u00d3\u00d5")
        buf.write("\7t\2\2\u00d4\u00d0\3\2\2\2\u00d4\u00d2\3\2\2\2\u00d5")
        buf.write("<\3\2\2\2\u00d6\u00d7\7(\2\2\u00d7\u00dc\7(\2\2\u00d8")
        buf.write("\u00d9\7c\2\2\u00d9\u00da\7p\2\2\u00da\u00dc\7f\2\2\u00db")
        buf.write("\u00d6\3\2\2\2\u00db\u00d8\3\2\2\2\u00dc>\3\2\2\2\u00dd")
        buf.write("\u00e2\7#\2\2\u00de\u00df\7p\2\2\u00df\u00e0\7q\2\2\u00e0")
        buf.write("\u00e2\7v\2\2\u00e1\u00dd\3\2\2\2\u00e1\u00de\3\2\2\2")
        buf.write("\u00e2@\3\2\2\2\u00e3\u00e4\7%\2\2\u00e4\u00e5\7k\2\2")
        buf.write("\u00e5\u00e6\7p\2\2\u00e6\u00e7\7e\2\2\u00e7\u00e8\7n")
        buf.write("\2\2\u00e8\u00e9\7w\2\2\u00e9\u00ea\7f\2\2\u00ea\u00eb")
        buf.write("\7g\2\2\u00ebB\3\2\2\2\u00ec\u00ed\5A!\2\u00ed\u00f1\5")
        buf.write("\67\34\2\u00ee\u00f0\13\2\2\2\u00ef\u00ee\3\2\2\2\u00f0")
        buf.write("\u00f3\3\2\2\2\u00f1\u00f2\3\2\2\2\u00f1\u00ef\3\2\2\2")
        buf.write("\u00f2\u00f4\3\2\2\2\u00f3\u00f1\3\2\2\2\u00f4\u00f5\5")
        buf.write("\63\32\2\u00f5\u0107\3\2\2\2\u00f6\u00fa\5A!\2\u00f7\u00f9")
        buf.write("\7\"\2\2\u00f8\u00f7\3\2\2\2\u00f9\u00fc\3\2\2\2\u00fa")
        buf.write("\u00f8\3\2\2\2\u00fa\u00fb\3\2\2\2\u00fb\u00fd\3\2\2\2")
        buf.write("\u00fc\u00fa\3\2\2\2\u00fd\u0101\5\67\34\2\u00fe\u0100")
        buf.write("\13\2\2\2\u00ff\u00fe\3\2\2\2\u0100\u0103\3\2\2\2\u0101")
        buf.write("\u0102\3\2\2\2\u0101\u00ff\3\2\2\2\u0102\u0104\3\2\2\2")
        buf.write("\u0103\u0101\3\2\2\2\u0104\u0105\5\63\32\2\u0105\u0107")
        buf.write("\3\2\2\2\u0106\u00ec\3\2\2\2\u0106\u00f6\3\2\2\2\u0107")
        buf.write("D\3\2\2\2\u0108\u0109\7]\2\2\u0109F\3\2\2\2\u010a\u010b")
        buf.write("\7_\2\2\u010bH\3\2\2\2\u010c\u010d\7*\2\2\u010dJ\3\2\2")
        buf.write("\2\u010e\u010f\7+\2\2\u010fL\3\2\2\2\u0110\u0111\7)\2")
        buf.write("\2\u0111\u0112\13\2\2\2\u0112\u0113\7)\2\2\u0113N\3\2")
        buf.write("\2\2\u0114\u0115\7x\2\2\u0115\u0116\7q\2\2\u0116\u0117")
        buf.write("\7k\2\2\u0117\u0118\7f\2\2\u0118P\3\2\2\2\u0119\u011a")
        buf.write("\7e\2\2\u011a\u011b\7j\2\2\u011b\u011c\7c\2\2\u011c\u011d")
        buf.write("\7t\2\2\u011dR\3\2\2\2\u011e\u011f\7h\2\2\u011f\u0120")
        buf.write("\7n\2\2\u0120\u0121\7q\2\2\u0121\u0122\7c\2\2\u0122\u0123")
        buf.write("\7v\2\2\u0123T\3\2\2\2\u0124\u0125\7k\2\2\u0125\u0126")
        buf.write("\7p\2\2\u0126\u0127\7v\2\2\u0127V\3\2\2\2\u0128\u0129")
        buf.write("\t\2\2\2\u0129X\3\2\2\2\u012a\u012b\t\3\2\2\u012bZ\3\2")
        buf.write("\2\2\u012c\u012e\t\4\2\2\u012d\u012c\3\2\2\2\u012e\u0132")
        buf.write("\3\2\2\2\u012f\u0131\t\5\2\2\u0130\u012f\3\2\2\2\u0131")
        buf.write("\u0134\3\2\2\2\u0132\u0130\3\2\2\2\u0132\u0133\3\2\2\2")
        buf.write("\u0133\\\3\2\2\2\u0134\u0132\3\2\2\2\u0135\u0136\7\60")
        buf.write("\2\2\u0136^\3\2\2\2\u0137\u013b\7$\2\2\u0138\u013a\13")
        buf.write("\2\2\2\u0139\u0138\3\2\2\2\u013a\u013d\3\2\2\2\u013b\u013c")
        buf.write("\3\2\2\2\u013b\u0139\3\2\2\2\u013c\u013e\3\2\2\2\u013d")
        buf.write("\u013b\3\2\2\2\u013e\u013f\7$\2\2\u013f`\3\2\2\2\u0140")
        buf.write("\u0142\t\6\2\2\u0141\u0140\3\2\2\2\u0142\u0143\3\2\2\2")
        buf.write("\u0143\u0141\3\2\2\2\u0143\u0144\3\2\2\2\u0144\u0145\3")
        buf.write("\2\2\2\u0145\u0146\b\61\2\2\u0146b\3\2\2\2\u0147\u0148")
        buf.write("\7\61\2\2\u0148\u0149\7\61\2\2\u0149\u014d\3\2\2\2\u014a")
        buf.write("\u014c\13\2\2\2\u014b\u014a\3\2\2\2\u014c\u014f\3\2\2")
        buf.write("\2\u014d\u014e\3\2\2\2\u014d\u014b\3\2\2\2\u014e\u0150")
        buf.write("\3\2\2\2\u014f\u014d\3\2\2\2\u0150\u0151\7\f\2\2\u0151")
        buf.write("\u0152\3\2\2\2\u0152\u0153\b\62\2\2\u0153d\3\2\2\2\u0154")
        buf.write("\u0155\7\61\2\2\u0155\u0156\7,\2\2\u0156\u015b\3\2\2\2")
        buf.write("\u0157\u015a\13\2\2\2\u0158\u015a\7\f\2\2\u0159\u0157")
        buf.write("\3\2\2\2\u0159\u0158\3\2\2\2\u015a\u015d\3\2\2\2\u015b")
        buf.write("\u015c\3\2\2\2\u015b\u0159\3\2\2\2\u015c\u015e\3\2\2\2")
        buf.write("\u015d\u015b\3\2\2\2\u015e\u015f\7,\2\2\u015f\u0160\7")
        buf.write("\61\2\2\u0160\u0161\3\2\2\2\u0161\u0162\b\63\2\2\u0162")
        buf.write("f\3\2\2\2\24\2\u00c6\u00ce\u00d4\u00db\u00e1\u00f1\u00fa")
        buf.write("\u0101\u0106\u012d\u0130\u0132\u013b\u0143\u014d\u0159")
        buf.write("\u015b\3\b\2\2")
        return buf.getvalue()


class cGrammarLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]


    T__0 = 1
    T__1 = 2
    T__2 = 3
    T__3 = 4
    T__4 = 5
    T__5 = 6
    T__6 = 7
    T__7 = 8
    T__8 = 9
    T__9 = 10
    T__10 = 11
    T__11 = 12
    T__12 = 13
    OPERATOR_AS = 14
    OPERATOR_PLUS = 15
    POST_OPERATOR_INCR = 16
    POST_OPERATOR_DECR = 17
    PRE_OPERATOR_INCR = 18
    PRE_OPERATOR_DECR = 19
    OPERATOR_MINUS = 20
    OPERATOR_DIV = 21
    OPERATOR_MUL = 22
    OPERATOR_EQ = 23
    OPERATOR_NE = 24
    OPERATOR_GT = 25
    OPERATOR_GE = 26
    OPERATOR_LT = 27
    OPERATOR_LE = 28
    OPERATOR_OR = 29
    OPERATOR_AND = 30
    OPERATOR_NOT = 31
    INCLUDE_MACRO = 32
    INCLUDE_FILE = 33
    LSQUAREBRACKET = 34
    RSQUAREBRACKET = 35
    LBRACKET = 36
    RBRACKET = 37
    CHARVALUE = 38
    VOID = 39
    CHAR = 40
    FLOAT = 41
    INT = 42
    DIGIT = 43
    NOTZERODIGIT = 44
    ID = 45
    POINT = 46
    STRING = 47
    WS = 48
    SL_COMMENT = 49
    ML_COMMENT = 50

    modeNames = [ "DEFAULT_MODE" ]

    literalNames = [ "<INVALID>",
            "';'", "'{'", "'}'", "','", "'break'", "'continue'", "'return'", 
            "'if'", "'else'", "'while'", "'for'", "'scanf'", "'printf'", 
            "'='", "'+'", "'-'", "'/'", "'*'", "'=='", "'!='", "'>'", "'<'", 
            "'#include'", "'['", "']'", "'('", "')'", "'void'", "'char'", 
            "'float'", "'int'", "'.'" ]

    symbolicNames = [ "<INVALID>",
            "OPERATOR_AS", "OPERATOR_PLUS", "POST_OPERATOR_INCR", "POST_OPERATOR_DECR", 
            "PRE_OPERATOR_INCR", "PRE_OPERATOR_DECR", "OPERATOR_MINUS", 
            "OPERATOR_DIV", "OPERATOR_MUL", "OPERATOR_EQ", "OPERATOR_NE", 
            "OPERATOR_GT", "OPERATOR_GE", "OPERATOR_LT", "OPERATOR_LE", 
            "OPERATOR_OR", "OPERATOR_AND", "OPERATOR_NOT", "INCLUDE_MACRO", 
            "INCLUDE_FILE", "LSQUAREBRACKET", "RSQUAREBRACKET", "LBRACKET", 
            "RBRACKET", "CHARVALUE", "VOID", "CHAR", "FLOAT", "INT", "DIGIT", 
            "NOTZERODIGIT", "ID", "POINT", "STRING", "WS", "SL_COMMENT", 
            "ML_COMMENT" ]

    ruleNames = [ "T__0", "T__1", "T__2", "T__3", "T__4", "T__5", "T__6", 
                  "T__7", "T__8", "T__9", "T__10", "T__11", "T__12", "OPERATOR_AS", 
                  "OPERATOR_PLUS", "POST_OPERATOR_INCR", "POST_OPERATOR_DECR", 
                  "PRE_OPERATOR_INCR", "PRE_OPERATOR_DECR", "OPERATOR_MINUS", 
                  "OPERATOR_DIV", "OPERATOR_MUL", "OPERATOR_EQ", "OPERATOR_NE", 
                  "OPERATOR_GT", "OPERATOR_GE", "OPERATOR_LT", "OPERATOR_LE", 
                  "OPERATOR_OR", "OPERATOR_AND", "OPERATOR_NOT", "INCLUDE_MACRO", 
                  "INCLUDE_FILE", "LSQUAREBRACKET", "RSQUAREBRACKET", "LBRACKET", 
                  "RBRACKET", "CHARVALUE", "VOID", "CHAR", "FLOAT", "INT", 
                  "DIGIT", "NOTZERODIGIT", "ID", "POINT", "STRING", "WS", 
                  "SL_COMMENT", "ML_COMMENT" ]

    grammarFileName = "cGrammar.g4"

    def __init__(self, input=None):
        super().__init__(input)
        self.checkVersion("4.6")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


